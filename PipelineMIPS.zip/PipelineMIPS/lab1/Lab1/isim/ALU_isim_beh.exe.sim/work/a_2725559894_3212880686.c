/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Galatis/Documents/Organwsi/Lab1/ALU.vhd";
extern char *IEEE_P_0774719531;
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_0774719531_sub_767668596_2162500114(char *, char *, char *, char *, char *, char *);
char *ieee_p_0774719531_sub_767740470_2162500114(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_2505268884_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2505484506_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2540846514_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2547962040_1035706684(char *, char *, char *, char *, int );
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_3798478767_503743352(char *, char *, char *, char *, char *, char *);


static void work_a_2725559894_3212880686_p_0(char *t0)
{
    char t32[16];
    char t35[16];
    char t40[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t33;
    char *t34;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned char t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned char t58;

LAB0:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t1 = (t0 + 5025);
    t4 = xsi_mem_cmp(t1, t2, 4U);
    if (t4 == 1)
        goto LAB3;

LAB14:    t5 = (t0 + 5029);
    t7 = xsi_mem_cmp(t5, t2, 4U);
    if (t7 == 1)
        goto LAB4;

LAB15:    t8 = (t0 + 5033);
    t10 = xsi_mem_cmp(t8, t2, 4U);
    if (t10 == 1)
        goto LAB5;

LAB16:    t11 = (t0 + 5037);
    t13 = xsi_mem_cmp(t11, t2, 4U);
    if (t13 == 1)
        goto LAB6;

LAB17:    t14 = (t0 + 5041);
    t16 = xsi_mem_cmp(t14, t2, 4U);
    if (t16 == 1)
        goto LAB7;

LAB18:    t17 = (t0 + 5045);
    t19 = xsi_mem_cmp(t17, t2, 4U);
    if (t19 == 1)
        goto LAB8;

LAB19:    t20 = (t0 + 5049);
    t22 = xsi_mem_cmp(t20, t2, 4U);
    if (t22 == 1)
        goto LAB9;

LAB20:    t23 = (t0 + 5053);
    t25 = xsi_mem_cmp(t23, t2, 4U);
    if (t25 == 1)
        goto LAB10;

LAB21:    t26 = (t0 + 5057);
    t28 = xsi_mem_cmp(t26, t2, 4U);
    if (t28 == 1)
        goto LAB11;

LAB22:    t29 = (t0 + 5061);
    t31 = xsi_mem_cmp(t29, t2, 4U);
    if (t31 == 1)
        goto LAB12;

LAB23:
LAB13:    xsi_set_current_line(66, ng0);
    t1 = (t0 + 5065);
    t3 = (t0 + 2872);
    t5 = (t3 + 32U);
    t6 = *((char **)t5);
    t8 = (t6 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);

LAB2:    t1 = (t0 + 2760);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(56, ng0);
    t33 = (t0 + 592U);
    t34 = *((char **)t33);
    t36 = ((IEEE_P_2592010699) + 2332);
    t37 = (t0 + 4788U);
    t33 = xsi_base_array_concat(t33, t35, t36, (char)99, (unsigned char)2, (char)97, t34, t37, (char)101);
    t38 = (t0 + 684U);
    t39 = *((char **)t38);
    t41 = ((IEEE_P_2592010699) + 2332);
    t42 = (t0 + 4804U);
    t38 = xsi_base_array_concat(t38, t40, t41, (char)99, (unsigned char)2, (char)97, t39, t42, (char)101);
    t43 = ieee_p_0774719531_sub_767668596_2162500114(IEEE_P_0774719531, t32, t33, t35, t38, t40);
    t44 = (t32 + 12U);
    t45 = *((unsigned int *)t44);
    t46 = (1U * t45);
    t47 = (33U != t46);
    if (t47 == 1)
        goto LAB25;

LAB26:    t48 = (t0 + 2836);
    t49 = (t48 + 32U);
    t50 = *((char **)t49);
    t51 = (t50 + 40U);
    t52 = *((char **)t51);
    memcpy(t52, t43, 33U);
    xsi_driver_first_trans_fast(t48);
    goto LAB2;

LAB4:    xsi_set_current_line(57, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = ((IEEE_P_2592010699) + 2332);
    t5 = (t0 + 4788U);
    t1 = xsi_base_array_concat(t1, t35, t3, (char)99, (unsigned char)3, (char)97, t2, t5, (char)101);
    t6 = (t0 + 684U);
    t8 = *((char **)t6);
    t9 = ((IEEE_P_2592010699) + 2332);
    t11 = (t0 + 4804U);
    t6 = xsi_base_array_concat(t6, t40, t9, (char)99, (unsigned char)3, (char)97, t8, t11, (char)101);
    t12 = ieee_p_0774719531_sub_767740470_2162500114(IEEE_P_0774719531, t32, t1, t35, t6, t40);
    t14 = (t32 + 12U);
    t45 = *((unsigned int *)t14);
    t46 = (1U * t45);
    t47 = (33U != t46);
    if (t47 == 1)
        goto LAB27;

LAB28:    t15 = (t0 + 2836);
    t17 = (t15 + 32U);
    t18 = *((char **)t17);
    t20 = (t18 + 40U);
    t21 = *((char **)t20);
    memcpy(t21, t12, 33U);
    xsi_driver_first_trans_fast(t15);
    goto LAB2;

LAB5:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = (t0 + 684U);
    t5 = *((char **)t3);
    t3 = (t0 + 4804U);
    t6 = ieee_p_2592010699_sub_3798478767_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t45 = *((unsigned int *)t8);
    t46 = (1U * t45);
    t47 = (32U != t46);
    if (t47 == 1)
        goto LAB29;

LAB30:    t9 = (t0 + 2872);
    t11 = (t9 + 32U);
    t12 = *((char **)t11);
    t14 = (t12 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t9);
    goto LAB2;

LAB6:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = (t0 + 684U);
    t5 = *((char **)t3);
    t3 = (t0 + 4804U);
    t6 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t32, t2, t1, t5, t3);
    t8 = (t32 + 12U);
    t45 = *((unsigned int *)t8);
    t46 = (1U * t45);
    t47 = (32U != t46);
    if (t47 == 1)
        goto LAB31;

LAB32:    t9 = (t0 + 2872);
    t11 = (t9 + 32U);
    t12 = *((char **)t11);
    t14 = (t12 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t6, 32U);
    xsi_driver_first_trans_fast(t9);
    goto LAB2;

LAB7:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t32, t2, t1);
    t5 = (t32 + 12U);
    t45 = *((unsigned int *)t5);
    t46 = (1U * t45);
    t47 = (32U != t46);
    if (t47 == 1)
        goto LAB33;

LAB34:    t6 = (t0 + 2872);
    t8 = (t6 + 32U);
    t9 = *((char **)t8);
    t11 = (t9 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t6);
    goto LAB2;

LAB8:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t4 = (31 - 31);
    t45 = (t4 * -1);
    t46 = (1U * t45);
    t53 = (0 + t46);
    t1 = (t2 + t53);
    t47 = *((unsigned char *)t1);
    t3 = (t0 + 592U);
    t5 = *((char **)t3);
    t54 = (31 - 31);
    t55 = (t54 * 1U);
    t56 = (0 + t55);
    t3 = (t5 + t56);
    t8 = ((IEEE_P_2592010699) + 2332);
    t9 = (t35 + 0U);
    t11 = (t9 + 0U);
    *((int *)t11) = 31;
    t11 = (t9 + 4U);
    *((int *)t11) = 1;
    t11 = (t9 + 8U);
    *((int *)t11) = -1;
    t7 = (1 - 31);
    t57 = (t7 * -1);
    t57 = (t57 + 1);
    t11 = (t9 + 12U);
    *((unsigned int *)t11) = t57;
    t6 = xsi_base_array_concat(t6, t32, t8, (char)99, t47, (char)97, t3, t35, (char)101);
    t57 = (1U + 31U);
    t58 = (32U != t57);
    if (t58 == 1)
        goto LAB35;

LAB36:    t11 = (t0 + 2872);
    t12 = (t11 + 32U);
    t14 = *((char **)t12);
    t15 = (t14 + 40U);
    t17 = *((char **)t15);
    memcpy(t17, t6, 32U);
    xsi_driver_first_trans_fast(t11);
    goto LAB2;

LAB9:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = ieee_p_1242562249_sub_2547962040_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 2872);
    t6 = (t5 + 32U);
    t8 = *((char **)t6);
    t9 = (t8 + 40U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB10:    xsi_set_current_line(63, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = ieee_p_1242562249_sub_2540846514_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 2872);
    t6 = (t5 + 32U);
    t8 = *((char **)t6);
    t9 = (t8 + 40U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB11:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = ieee_p_1242562249_sub_2505268884_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 2872);
    t6 = (t5 + 32U);
    t8 = *((char **)t6);
    t9 = (t8 + 40U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB12:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t1 = (t0 + 4788U);
    t3 = ieee_p_1242562249_sub_2505484506_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 2872);
    t6 = (t5 + 32U);
    t8 = *((char **)t6);
    t9 = (t8 + 40U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB24:;
LAB25:    xsi_size_not_matching(33U, t46, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(33U, t46, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(32U, t46, 0);
    goto LAB30;

LAB31:    xsi_size_not_matching(32U, t46, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(32U, t46, 0);
    goto LAB34;

LAB35:    xsi_size_not_matching(32U, t57, 0);
    goto LAB36;

}

static void work_a_2725559894_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t1 = (t0 + 5097);
    t4 = xsi_mem_cmp(t1, t2, 32U);
    if (t4 == 1)
        goto LAB3;

LAB5:
LAB4:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 2908);
    t2 = (t1 + 32U);
    t3 = *((char **)t2);
    t5 = (t3 + 40U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t1 = (t0 + 2768);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(74, ng0);
    t5 = (t0 + 2908);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t5);
    goto LAB2;

LAB6:;
}

static void work_a_2725559894_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    static char *nl0[] = {&&LAB5, &&LAB5, &&LAB3, &&LAB4, &&LAB5, &&LAB5, &&LAB5, &&LAB5, &&LAB5};

LAB0:    xsi_set_current_line(81, ng0);
    t1 = (t0 + 1236U);
    t2 = *((char **)t1);
    t3 = (32 - 32);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (char *)((nl0) + t7);
    goto **((char **)t8);

LAB2:    t1 = (t0 + 2776);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(82, ng0);
    t9 = (t0 + 2944);
    t10 = (t9 + 32U);
    t11 = *((char **)t10);
    t12 = (t11 + 40U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB2;

LAB4:    xsi_set_current_line(83, ng0);
    t1 = (t0 + 2944);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

LAB5:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 2944);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = (unsigned char)1;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB2;

}

static void work_a_2725559894_3212880686_p_3(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned char t15;
    unsigned char t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    char *t24;
    char *t25;
    int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned char t30;
    unsigned char t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;

LAB0:    xsi_set_current_line(88, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t4 = (31 - 31);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t2 = (t3 + t7);
    t8 = *((unsigned char *)t2);
    t9 = (t0 + 684U);
    t10 = *((char **)t9);
    t11 = (31 - 31);
    t12 = (t11 * -1);
    t13 = (1U * t12);
    t14 = (0 + t13);
    t9 = (t10 + t14);
    t15 = *((unsigned char *)t9);
    t16 = (t8 == t15);
    if (t16 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB3;

LAB4:
LAB8:    t37 = (t0 + 2980);
    t38 = (t37 + 32U);
    t39 = *((char **)t38);
    t40 = (t39 + 40U);
    t41 = *((char **)t40);
    *((unsigned char *)t41) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t37);

LAB2:    t42 = (t0 + 2784);
    *((int *)t42) = 1;

LAB1:    return;
LAB3:    t32 = (t0 + 2980);
    t33 = (t32 + 32U);
    t34 = *((char **)t33);
    t35 = (t34 + 40U);
    t36 = *((char **)t35);
    *((unsigned char *)t36) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t32);
    goto LAB2;

LAB5:    t17 = (t0 + 684U);
    t18 = *((char **)t17);
    t19 = (31 - 31);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t17 = (t18 + t22);
    t23 = *((unsigned char *)t17);
    t24 = (t0 + 1236U);
    t25 = *((char **)t24);
    t26 = (31 - 32);
    t27 = (t26 * -1);
    t28 = (1U * t27);
    t29 = (0 + t28);
    t24 = (t25 + t29);
    t30 = *((unsigned char *)t24);
    t31 = (t23 != t30);
    t1 = t31;
    goto LAB7;

LAB9:    goto LAB2;

}

static void work_a_2725559894_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(93, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t1 = (t0 + 5129);
    t4 = xsi_mem_cmp(t1, t2, 4U);
    if (t4 == 1)
        goto LAB3;

LAB6:    t5 = (t0 + 5133);
    t7 = xsi_mem_cmp(t5, t2, 4U);
    if (t7 == 1)
        goto LAB4;

LAB7:
LAB5:    xsi_set_current_line(96, ng0);
    t1 = (t0 + 1328U);
    t2 = *((char **)t1);
    t1 = (t0 + 3016);
    t3 = (t1 + 32U);
    t5 = *((char **)t3);
    t6 = (t5 + 40U);
    t8 = *((char **)t6);
    memcpy(t8, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t1 = (t0 + 2792);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(94, ng0);
    t8 = (t0 + 1236U);
    t9 = *((char **)t8);
    t10 = (32 - 31);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t8 = (t9 + t12);
    t13 = (t0 + 3016);
    t14 = (t13 + 32U);
    t15 = *((char **)t14);
    t16 = (t15 + 40U);
    t17 = *((char **)t16);
    memcpy(t17, t8, 32U);
    xsi_driver_first_trans_fast_port(t13);
    goto LAB2;

LAB4:    xsi_set_current_line(95, ng0);
    t1 = (t0 + 1236U);
    t2 = *((char **)t1);
    t10 = (32 - 31);
    t11 = (t10 * 1U);
    t12 = (0 + t11);
    t1 = (t2 + t12);
    t3 = (t0 + 3016);
    t5 = (t3 + 32U);
    t6 = *((char **)t5);
    t8 = (t6 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast_port(t3);
    goto LAB2;

LAB8:;
}


extern void work_a_2725559894_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2725559894_3212880686_p_0,(void *)work_a_2725559894_3212880686_p_1,(void *)work_a_2725559894_3212880686_p_2,(void *)work_a_2725559894_3212880686_p_3,(void *)work_a_2725559894_3212880686_p_4};
	xsi_register_didat("work_a_2725559894_3212880686", "isim/ALU_isim_beh.exe.sim/work/a_2725559894_3212880686.didat");
	xsi_register_executes(pe);
}
