/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Galatis/Documents/Organwsi/1-2-3/lab5/Lab2/Extension.vhd";



static void work_a_4122381622_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned int t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned char t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned char t23;
    unsigned char t24;
    unsigned char t25;
    unsigned char t26;
    unsigned char t27;
    unsigned int t28;
    char *t29;
    unsigned char t30;
    unsigned int t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned char t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t44;
    unsigned int t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned char t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;

LAB0:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 3470);
    t5 = 1;
    if (6U == 6U)
        goto LAB8;

LAB9:    t5 = 0;

LAB10:    if (t5 == 1)
        goto LAB5;

LAB6:    t9 = (t0 + 592U);
    t10 = *((char **)t9);
    t9 = (t0 + 3476);
    t12 = 1;
    if (6U == 6U)
        goto LAB14;

LAB15:    t12 = 0;

LAB16:    t1 = t12;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 3482);
    t1 = 1;
    if (6U == 6U)
        goto LAB22;

LAB23:    t1 = 0;

LAB24:    if (t1 != 0)
        goto LAB20;

LAB21:    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 3488);
    t25 = 1;
    if (6U == 6U)
        goto LAB45;

LAB46:    t25 = 0;

LAB47:    if (t25 == 1)
        goto LAB42;

LAB43:    t9 = (t0 + 592U);
    t10 = *((char **)t9);
    t9 = (t0 + 3494);
    t26 = 1;
    if (6U == 6U)
        goto LAB51;

LAB52:    t26 = 0;

LAB53:    t24 = t26;

LAB44:    if (t24 == 1)
        goto LAB39;

LAB40:    t16 = (t0 + 592U);
    t17 = *((char **)t16);
    t16 = (t0 + 3500);
    t27 = 1;
    if (6U == 6U)
        goto LAB57;

LAB58:    t27 = 0;

LAB59:    t23 = t27;

LAB41:    if (t23 == 1)
        goto LAB36;

LAB37:    t21 = (t0 + 592U);
    t22 = *((char **)t21);
    t21 = (t0 + 3506);
    t30 = 1;
    if (6U == 6U)
        goto LAB63;

LAB64:    t30 = 0;

LAB65:    t12 = t30;

LAB38:    if (t12 == 1)
        goto LAB33;

LAB34:    t34 = (t0 + 592U);
    t35 = *((char **)t34);
    t34 = (t0 + 3512);
    t37 = 1;
    if (6U == 6U)
        goto LAB69;

LAB70:    t37 = 0;

LAB71:    t5 = t37;

LAB35:    if (t5 == 1)
        goto LAB30;

LAB31:    t41 = (t0 + 592U);
    t42 = *((char **)t41);
    t41 = (t0 + 3518);
    t44 = 1;
    if (6U == 6U)
        goto LAB75;

LAB76:    t44 = 0;

LAB77:    t1 = t44;

LAB32:    if (t1 != 0)
        goto LAB28;

LAB29:    t2 = (t0 + 592U);
    t3 = *((char **)t2);
    t2 = (t0 + 3524);
    t12 = 1;
    if (6U == 6U)
        goto LAB89;

LAB90:    t12 = 0;

LAB91:    if (t12 == 1)
        goto LAB86;

LAB87:    t9 = (t0 + 592U);
    t10 = *((char **)t9);
    t9 = (t0 + 3530);
    t23 = 1;
    if (6U == 6U)
        goto LAB95;

LAB96:    t23 = 0;

LAB97:    t5 = t23;

LAB88:    if (t5 == 1)
        goto LAB83;

LAB84:    t16 = (t0 + 592U);
    t17 = *((char **)t16);
    t16 = (t0 + 3536);
    t24 = 1;
    if (6U == 6U)
        goto LAB101;

LAB102:    t24 = 0;

LAB103:    t1 = t24;

LAB85:    if (t1 != 0)
        goto LAB81;

LAB82:
LAB3:    t2 = (t0 + 1868);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(46, ng0);
    t16 = xsi_get_transient_memory(16U);
    memset(t16, 0, 16U);
    t17 = t16;
    memset(t17, (unsigned char)2, 16U);
    t18 = (t0 + 1920);
    t19 = (t18 + 32U);
    t20 = *((char **)t19);
    t21 = (t20 + 40U);
    t22 = *((char **)t21);
    memcpy(t22, t16, 16U);
    xsi_driver_first_trans_delta(t18, 0U, 16U, 0LL);
    xsi_set_current_line(47, ng0);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t2 = (t0 + 1920);
    t4 = (t2 + 32U);
    t7 = *((char **)t4);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);
    goto LAB3;

LAB5:    t1 = (unsigned char)1;
    goto LAB7;

LAB8:    t6 = 0;

LAB11:    if (t6 < 6U)
        goto LAB12;
    else
        goto LAB10;

LAB12:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB9;

LAB13:    t6 = (t6 + 1);
    goto LAB11;

LAB14:    t13 = 0;

LAB17:    if (t13 < 6U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB15;

LAB19:    t13 = (t13 + 1);
    goto LAB17;

LAB20:    xsi_set_current_line(49, ng0);
    t9 = (t0 + 684U);
    t10 = *((char **)t9);
    t9 = (t0 + 1920);
    t11 = (t9 + 32U);
    t14 = *((char **)t11);
    t15 = (t14 + 40U);
    t16 = *((char **)t15);
    memcpy(t16, t10, 16U);
    xsi_driver_first_trans_delta(t9, 0U, 16U, 0LL);
    xsi_set_current_line(50, ng0);
    t2 = xsi_get_transient_memory(16U);
    memset(t2, 0, 16U);
    t3 = t2;
    memset(t3, (unsigned char)2, 16U);
    t4 = (t0 + 1920);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 16U);
    xsi_driver_first_trans_delta(t4, 16U, 16U, 0LL);
    goto LAB3;

LAB22:    t6 = 0;

LAB25:    if (t6 < 6U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB23;

LAB27:    t6 = (t6 + 1);
    goto LAB25;

LAB28:    xsi_set_current_line(52, ng0);
    t48 = xsi_get_transient_memory(16U);
    memset(t48, 0, 16U);
    t49 = t48;
    t50 = (t0 + 684U);
    t51 = *((char **)t50);
    t52 = (15 - 15);
    t53 = (t52 * -1);
    t54 = (1U * t53);
    t55 = (0 + t54);
    t50 = (t51 + t55);
    t56 = *((unsigned char *)t50);
    memset(t49, t56, 16U);
    t57 = (t0 + 1920);
    t58 = (t57 + 32U);
    t59 = *((char **)t58);
    t60 = (t59 + 40U);
    t61 = *((char **)t60);
    memcpy(t61, t48, 16U);
    xsi_driver_first_trans_delta(t57, 0U, 16U, 0LL);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t2 = (t0 + 1920);
    t4 = (t2 + 32U);
    t7 = *((char **)t4);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 16U, 16U, 0LL);
    goto LAB3;

LAB30:    t1 = (unsigned char)1;
    goto LAB32;

LAB33:    t5 = (unsigned char)1;
    goto LAB35;

LAB36:    t12 = (unsigned char)1;
    goto LAB38;

LAB39:    t23 = (unsigned char)1;
    goto LAB41;

LAB42:    t24 = (unsigned char)1;
    goto LAB44;

LAB45:    t6 = 0;

LAB48:    if (t6 < 6U)
        goto LAB49;
    else
        goto LAB47;

LAB49:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB46;

LAB50:    t6 = (t6 + 1);
    goto LAB48;

LAB51:    t13 = 0;

LAB54:    if (t13 < 6U)
        goto LAB55;
    else
        goto LAB53;

LAB55:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB52;

LAB56:    t13 = (t13 + 1);
    goto LAB54;

LAB57:    t28 = 0;

LAB60:    if (t28 < 6U)
        goto LAB61;
    else
        goto LAB59;

LAB61:    t19 = (t17 + t28);
    t20 = (t16 + t28);
    if (*((unsigned char *)t19) != *((unsigned char *)t20))
        goto LAB58;

LAB62:    t28 = (t28 + 1);
    goto LAB60;

LAB63:    t31 = 0;

LAB66:    if (t31 < 6U)
        goto LAB67;
    else
        goto LAB65;

LAB67:    t32 = (t22 + t31);
    t33 = (t21 + t31);
    if (*((unsigned char *)t32) != *((unsigned char *)t33))
        goto LAB64;

LAB68:    t31 = (t31 + 1);
    goto LAB66;

LAB69:    t38 = 0;

LAB72:    if (t38 < 6U)
        goto LAB73;
    else
        goto LAB71;

LAB73:    t39 = (t35 + t38);
    t40 = (t34 + t38);
    if (*((unsigned char *)t39) != *((unsigned char *)t40))
        goto LAB70;

LAB74:    t38 = (t38 + 1);
    goto LAB72;

LAB75:    t45 = 0;

LAB78:    if (t45 < 6U)
        goto LAB79;
    else
        goto LAB77;

LAB79:    t46 = (t42 + t45);
    t47 = (t41 + t45);
    if (*((unsigned char *)t46) != *((unsigned char *)t47))
        goto LAB76;

LAB80:    t45 = (t45 + 1);
    goto LAB78;

LAB81:    xsi_set_current_line(55, ng0);
    t21 = xsi_get_transient_memory(14U);
    memset(t21, 0, 14U);
    t22 = t21;
    t29 = (t0 + 684U);
    t32 = *((char **)t29);
    t52 = (15 - 15);
    t31 = (t52 * -1);
    t38 = (1U * t31);
    t45 = (0 + t38);
    t29 = (t32 + t45);
    t25 = *((unsigned char *)t29);
    memset(t22, t25, 14U);
    t33 = (t0 + 1920);
    t34 = (t33 + 32U);
    t35 = *((char **)t34);
    t36 = (t35 + 40U);
    t39 = *((char **)t36);
    memcpy(t39, t21, 14U);
    xsi_driver_first_trans_delta(t33, 0U, 14U, 0LL);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t2 = (t0 + 1920);
    t4 = (t2 + 32U);
    t7 = *((char **)t4);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_delta(t2, 14U, 16U, 0LL);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 3542);
    t1 = (2U != 2U);
    if (t1 == 1)
        goto LAB107;

LAB108:    t4 = (t0 + 1920);
    t7 = (t4 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 40U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 2U);
    xsi_driver_first_trans_delta(t4, 30U, 2U, 0LL);
    goto LAB3;

LAB83:    t1 = (unsigned char)1;
    goto LAB85;

LAB86:    t5 = (unsigned char)1;
    goto LAB88;

LAB89:    t6 = 0;

LAB92:    if (t6 < 6U)
        goto LAB93;
    else
        goto LAB91;

LAB93:    t7 = (t3 + t6);
    t8 = (t2 + t6);
    if (*((unsigned char *)t7) != *((unsigned char *)t8))
        goto LAB90;

LAB94:    t6 = (t6 + 1);
    goto LAB92;

LAB95:    t13 = 0;

LAB98:    if (t13 < 6U)
        goto LAB99;
    else
        goto LAB97;

LAB99:    t14 = (t10 + t13);
    t15 = (t9 + t13);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB96;

LAB100:    t13 = (t13 + 1);
    goto LAB98;

LAB101:    t28 = 0;

LAB104:    if (t28 < 6U)
        goto LAB105;
    else
        goto LAB103;

LAB105:    t19 = (t17 + t28);
    t20 = (t16 + t28);
    if (*((unsigned char *)t19) != *((unsigned char *)t20))
        goto LAB102;

LAB106:    t28 = (t28 + 1);
    goto LAB104;

LAB107:    xsi_size_not_matching(2U, 2U, 0);
    goto LAB108;

}

static void work_a_4122381622_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(60, ng0);

LAB3:    t1 = (t0 + 868U);
    t2 = *((char **)t1);
    t1 = (t0 + 1956);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 1876);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_4122381622_3212880686_init()
{
	static char *pe[] = {(void *)work_a_4122381622_3212880686_p_0,(void *)work_a_4122381622_3212880686_p_1};
	xsi_register_didat("work_a_4122381622_3212880686", "isim/Processor_Test_isim_beh.exe.sim/work/a_4122381622_3212880686.didat");
	xsi_register_executes(pe);
}
