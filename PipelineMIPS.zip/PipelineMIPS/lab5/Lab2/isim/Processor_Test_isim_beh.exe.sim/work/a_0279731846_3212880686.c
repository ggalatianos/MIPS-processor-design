/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Galatis/Documents/Organwsi/1-2-3/lab5/Lab2/Exception.vhd";
extern char *IEEE_P_2592010699;



static void work_a_0279731846_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    unsigned char t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned char t17;
    unsigned int t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned char t24;
    unsigned int t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    unsigned char t31;
    unsigned int t32;
    char *t33;
    char *t34;
    char *t35;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;

LAB0:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 868U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3876);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 592U);
    t8 = *((char **)t1);
    t1 = (t0 + 7532);
    t10 = 1;
    if (6U == 6U)
        goto LAB17;

LAB18:    t10 = 0;

LAB19:    if ((!(t10)) == 1)
        goto LAB14;

LAB15:    t7 = (unsigned char)0;

LAB16:    if (t7 == 1)
        goto LAB11;

LAB12:    t6 = (unsigned char)0;

LAB13:    if (t6 == 1)
        goto LAB8;

LAB9:    t5 = (unsigned char)0;

LAB10:    if (t5 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 684U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB41;

LAB42:    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t1 = (t0 + 2156U);
    t8 = *((char **)t1);
    t1 = ((IEEE_P_2592010699) + 2332);
    t4 = xsi_vhdl_greater(t1, t2, 32U, t8, 32U);
    if (t4 == 1)
        goto LAB45;

LAB46:    t3 = (unsigned char)0;

LAB47:    if (t3 != 0)
        goto LAB43;

LAB44:    xsi_set_current_line(80, ng0);
    t1 = (t0 + 7664);
    t8 = (t0 + 3968);
    t9 = (t8 + 32U);
    t12 = *((char **)t9);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 2U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(81, ng0);
    t1 = (t0 + 7666);
    t8 = (t0 + 4004);
    t9 = (t8 + 32U);
    t12 = *((char **)t9);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 32U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(82, ng0);
    t1 = (t0 + 4040);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 4148);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(84, ng0);
    t1 = (t0 + 4076);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(62, ng0);
    t35 = (t0 + 7556);
    t37 = (t0 + 3968);
    t38 = (t37 + 32U);
    t39 = *((char **)t38);
    t40 = (t39 + 40U);
    t41 = *((char **)t40);
    memcpy(t41, t35, 2U);
    xsi_driver_first_trans_fast(t37);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 7558);
    t8 = (t0 + 4004);
    t9 = (t8 + 32U);
    t12 = *((char **)t9);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 32U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(64, ng0);
    t1 = (t0 + 4040);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 4076);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(66, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB8:    t28 = (t0 + 592U);
    t29 = *((char **)t28);
    t28 = (t0 + 7550);
    t31 = 1;
    if (6U == 6U)
        goto LAB35;

LAB36:    t31 = 0;

LAB37:    t5 = (!(t31));
    goto LAB10;

LAB11:    t21 = (t0 + 592U);
    t22 = *((char **)t21);
    t21 = (t0 + 7544);
    t24 = 1;
    if (6U == 6U)
        goto LAB29;

LAB30:    t24 = 0;

LAB31:    t6 = (!(t24));
    goto LAB13;

LAB14:    t14 = (t0 + 592U);
    t15 = *((char **)t14);
    t14 = (t0 + 7538);
    t17 = 1;
    if (6U == 6U)
        goto LAB23;

LAB24:    t17 = 0;

LAB25:    t7 = (!(t17));
    goto LAB16;

LAB17:    t11 = 0;

LAB20:    if (t11 < 6U)
        goto LAB21;
    else
        goto LAB19;

LAB21:    t12 = (t8 + t11);
    t13 = (t1 + t11);
    if (*((unsigned char *)t12) != *((unsigned char *)t13))
        goto LAB18;

LAB22:    t11 = (t11 + 1);
    goto LAB20;

LAB23:    t18 = 0;

LAB26:    if (t18 < 6U)
        goto LAB27;
    else
        goto LAB25;

LAB27:    t19 = (t15 + t18);
    t20 = (t14 + t18);
    if (*((unsigned char *)t19) != *((unsigned char *)t20))
        goto LAB24;

LAB28:    t18 = (t18 + 1);
    goto LAB26;

LAB29:    t25 = 0;

LAB32:    if (t25 < 6U)
        goto LAB33;
    else
        goto LAB31;

LAB33:    t26 = (t22 + t25);
    t27 = (t21 + t25);
    if (*((unsigned char *)t26) != *((unsigned char *)t27))
        goto LAB30;

LAB34:    t25 = (t25 + 1);
    goto LAB32;

LAB35:    t32 = 0;

LAB38:    if (t32 < 6U)
        goto LAB39;
    else
        goto LAB37;

LAB39:    t33 = (t29 + t32);
    t34 = (t28 + t32);
    if (*((unsigned char *)t33) != *((unsigned char *)t34))
        goto LAB36;

LAB40:    t32 = (t32 + 1);
    goto LAB38;

LAB41:    xsi_set_current_line(68, ng0);
    t1 = (t0 + 7590);
    t9 = (t0 + 3968);
    t12 = (t9 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 40U);
    t15 = *((char **)t14);
    memcpy(t15, t1, 2U);
    xsi_driver_first_trans_fast(t9);
    xsi_set_current_line(69, ng0);
    t1 = (t0 + 7592);
    t8 = (t0 + 4004);
    t9 = (t8 + 32U);
    t12 = *((char **)t9);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 32U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(70, ng0);
    t1 = (t0 + 4148);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(71, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(72, ng0);
    t1 = (t0 + 4076);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB43:    xsi_set_current_line(74, ng0);
    t16 = (t0 + 7630);
    t20 = (t0 + 3968);
    t21 = (t20 + 32U);
    t22 = *((char **)t21);
    t23 = (t22 + 40U);
    t26 = *((char **)t23);
    memcpy(t26, t16, 2U);
    xsi_driver_first_trans_fast(t20);
    xsi_set_current_line(75, ng0);
    t1 = (t0 + 7632);
    t8 = (t0 + 4004);
    t9 = (t8 + 32U);
    t12 = *((char **)t9);
    t13 = (t12 + 40U);
    t14 = *((char **)t13);
    memcpy(t14, t1, 32U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(76, ng0);
    t1 = (t0 + 4148);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(77, ng0);
    t1 = (t0 + 4112);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(78, ng0);
    t1 = (t0 + 4076);
    t2 = (t1 + 32U);
    t8 = *((char **)t2);
    t9 = (t8 + 40U);
    t12 = *((char **)t9);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB45:    t9 = (t0 + 960U);
    t12 = *((char **)t9);
    t9 = (t0 + 7624);
    t5 = 1;
    if (6U == 6U)
        goto LAB48;

LAB49:    t5 = 0;

LAB50:    t3 = t5;
    goto LAB47;

LAB48:    t11 = 0;

LAB51:    if (t11 < 6U)
        goto LAB52;
    else
        goto LAB50;

LAB52:    t14 = (t12 + t11);
    t15 = (t9 + t11);
    if (*((unsigned char *)t14) != *((unsigned char *)t15))
        goto LAB49;

LAB53:    t11 = (t11 + 1);
    goto LAB51;

}

static void work_a_0279731846_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(89, ng0);

LAB3:    t1 = (t0 + 1604U);
    t2 = *((char **)t1);
    t1 = (t0 + 4184);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 2U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 3884);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0279731846_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(90, ng0);

LAB3:    t1 = (t0 + 1696U);
    t2 = *((char **)t1);
    t1 = (t0 + 4220);
    t3 = (t1 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 40U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 3892);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0279731846_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(91, ng0);

LAB3:    t1 = (t0 + 1788U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4256);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 3900);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0279731846_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(92, ng0);

LAB3:    t1 = (t0 + 1880U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4292);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 3908);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0279731846_3212880686_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(93, ng0);

LAB3:    t1 = (t0 + 1972U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4328);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 3916);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0279731846_3212880686_p_6(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(94, ng0);

LAB3:    t1 = (t0 + 2064U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4364);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 3924);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0279731846_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0279731846_3212880686_p_0,(void *)work_a_0279731846_3212880686_p_1,(void *)work_a_0279731846_3212880686_p_2,(void *)work_a_0279731846_3212880686_p_3,(void *)work_a_0279731846_3212880686_p_4,(void *)work_a_0279731846_3212880686_p_5,(void *)work_a_0279731846_3212880686_p_6};
	xsi_register_didat("work_a_0279731846_3212880686", "isim/Processor_Test_isim_beh.exe.sim/work/a_0279731846_3212880686.didat");
	xsi_register_executes(pe);
}
