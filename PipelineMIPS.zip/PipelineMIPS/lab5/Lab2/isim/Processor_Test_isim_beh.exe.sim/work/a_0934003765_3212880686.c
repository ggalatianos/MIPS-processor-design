/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Galatis/Documents/Organwsi/1-2-3/lab5/Lab2/ForwardUnit.vhd";



static void work_a_0934003765_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    unsigned int t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned char t31;
    unsigned char t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned char t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned char t46;
    unsigned int t47;
    char *t48;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 3902);
    t8 = 1;
    if (6U == 6U)
        goto LAB5;

LAB6:    t8 = 0;

LAB7:    if (t8 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 3912);
    t19 = 1;
    if (6U == 6U)
        goto LAB16;

LAB17:    t19 = 0;

LAB18:    if (t19 == 1)
        goto LAB13;

LAB14:    t12 = (t0 + 592U);
    t13 = *((char **)t12);
    t20 = (31 - 31);
    t21 = (t20 * 1U);
    t22 = (0 + t21);
    t12 = (t13 + t22);
    t14 = (t0 + 3918);
    t23 = 1;
    if (6U == 6U)
        goto LAB22;

LAB23:    t23 = 0;

LAB24:    t8 = t23;

LAB15:    if (t8 != 0)
        goto LAB11;

LAB12:    t1 = (t0 + 868U);
    t2 = *((char **)t1);
    t19 = *((unsigned char *)t2);
    t23 = (t19 == (unsigned char)3);
    if (t23 == 1)
        goto LAB30;

LAB31:    t8 = (unsigned char)0;

LAB32:    if (t8 != 0)
        goto LAB28;

LAB29:    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t19 = *((unsigned char *)t2);
    t23 = (t19 == (unsigned char)3);
    if (t23 == 1)
        goto LAB68;

LAB69:    t8 = (unsigned char)0;

LAB70:    if (t8 != 0)
        goto LAB66;

LAB67:    xsi_set_current_line(82, ng0);
    t1 = (t0 + 3944);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(83, ng0);
    t1 = (t0 + 3946);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);

LAB3:    t1 = (t0 + 2000);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(49, ng0);
    t12 = (t0 + 3908);
    t14 = (t0 + 2044);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    memcpy(t18, t12, 2U);
    xsi_driver_first_trans_fast_port(t14);
    xsi_set_current_line(50, ng0);
    t1 = (t0 + 3910);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB5:    t9 = 0;

LAB8:    if (t9 < 6U)
        goto LAB9;
    else
        goto LAB7;

LAB9:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB6;

LAB10:    t9 = (t9 + 1);
    goto LAB8;

LAB11:    xsi_set_current_line(52, ng0);
    t18 = (t0 + 3924);
    t26 = (t0 + 2044);
    t27 = (t26 + 32U);
    t28 = *((char **)t27);
    t29 = (t28 + 40U);
    t30 = *((char **)t29);
    memcpy(t30, t18, 2U);
    xsi_driver_first_trans_fast_port(t26);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 3926);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB13:    t8 = (unsigned char)1;
    goto LAB15;

LAB16:    t9 = 0;

LAB19:    if (t9 < 6U)
        goto LAB20;
    else
        goto LAB18;

LAB20:    t10 = (t1 + t9);
    t11 = (t6 + t9);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB17;

LAB21:    t9 = (t9 + 1);
    goto LAB19;

LAB22:    t24 = 0;

LAB25:    if (t24 < 6U)
        goto LAB26;
    else
        goto LAB24;

LAB26:    t16 = (t12 + t24);
    t17 = (t14 + t24);
    if (*((unsigned char *)t16) != *((unsigned char *)t17))
        goto LAB23;

LAB27:    t24 = (t24 + 1);
    goto LAB25;

LAB28:    xsi_set_current_line(56, ng0);
    t25 = (t0 + 592U);
    t26 = *((char **)t25);
    t40 = (31 - 25);
    t41 = (t40 * 1U);
    t42 = (0 + t41);
    t25 = (t26 + t42);
    t27 = (t0 + 684U);
    t28 = *((char **)t27);
    t43 = (31 - 20);
    t44 = (t43 * 1U);
    t45 = (0 + t44);
    t27 = (t28 + t45);
    t46 = 1;
    if (5U == 5U)
        goto LAB51;

LAB52:    t46 = 0;

LAB53:    if (t46 != 0)
        goto LAB48;

LAB50:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 3930);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);

LAB49:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 684U);
    t7 = *((char **)t6);
    t9 = (31 - 20);
    t20 = (t9 * 1U);
    t21 = (0 + t20);
    t6 = (t7 + t21);
    t8 = 1;
    if (5U == 5U)
        goto LAB60;

LAB61:    t8 = 0;

LAB62:    if (t8 != 0)
        goto LAB57;

LAB59:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3934);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);

LAB58:    goto LAB3;

LAB30:    t1 = (t0 + 592U);
    t6 = *((char **)t1);
    t3 = (31 - 25);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t6 + t5);
    t7 = (t0 + 684U);
    t10 = *((char **)t7);
    t9 = (31 - 20);
    t20 = (t9 * 1U);
    t21 = (0 + t20);
    t7 = (t10 + t21);
    t32 = 1;
    if (5U == 5U)
        goto LAB36;

LAB37:    t32 = 0;

LAB38:    if (t32 == 1)
        goto LAB33;

LAB34:    t13 = (t0 + 592U);
    t14 = *((char **)t13);
    t24 = (31 - 15);
    t33 = (t24 * 1U);
    t34 = (0 + t33);
    t13 = (t14 + t34);
    t15 = (t0 + 684U);
    t16 = *((char **)t15);
    t35 = (31 - 20);
    t36 = (t35 * 1U);
    t37 = (0 + t36);
    t15 = (t16 + t37);
    t38 = 1;
    if (5U == 5U)
        goto LAB42;

LAB43:    t38 = 0;

LAB44:    t31 = t38;

LAB35:    t8 = t31;
    goto LAB32;

LAB33:    t31 = (unsigned char)1;
    goto LAB35;

LAB36:    t22 = 0;

LAB39:    if (t22 < 5U)
        goto LAB40;
    else
        goto LAB38;

LAB40:    t11 = (t1 + t22);
    t12 = (t7 + t22);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB37;

LAB41:    t22 = (t22 + 1);
    goto LAB39;

LAB42:    t39 = 0;

LAB45:    if (t39 < 5U)
        goto LAB46;
    else
        goto LAB44;

LAB46:    t17 = (t13 + t39);
    t18 = (t15 + t39);
    if (*((unsigned char *)t17) != *((unsigned char *)t18))
        goto LAB43;

LAB47:    t39 = (t39 + 1);
    goto LAB45;

LAB48:    xsi_set_current_line(57, ng0);
    t48 = (t0 + 3928);
    t50 = (t0 + 2044);
    t51 = (t50 + 32U);
    t52 = *((char **)t51);
    t53 = (t52 + 40U);
    t54 = *((char **)t53);
    memcpy(t54, t48, 2U);
    xsi_driver_first_trans_fast_port(t50);
    goto LAB49;

LAB51:    t47 = 0;

LAB54:    if (t47 < 5U)
        goto LAB55;
    else
        goto LAB53;

LAB55:    t29 = (t25 + t47);
    t30 = (t27 + t47);
    if (*((unsigned char *)t29) != *((unsigned char *)t30))
        goto LAB52;

LAB56:    t47 = (t47 + 1);
    goto LAB54;

LAB57:    xsi_set_current_line(63, ng0);
    t12 = (t0 + 3932);
    t14 = (t0 + 2080);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    memcpy(t18, t12, 2U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB58;

LAB60:    t22 = 0;

LAB63:    if (t22 < 5U)
        goto LAB64;
    else
        goto LAB62;

LAB64:    t10 = (t1 + t22);
    t11 = (t6 + t22);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB61;

LAB65:    t22 = (t22 + 1);
    goto LAB63;

LAB66:    xsi_set_current_line(70, ng0);
    t25 = (t0 + 592U);
    t26 = *((char **)t25);
    t40 = (31 - 25);
    t41 = (t40 * 1U);
    t42 = (0 + t41);
    t25 = (t26 + t42);
    t27 = (t0 + 776U);
    t28 = *((char **)t27);
    t43 = (31 - 20);
    t44 = (t43 * 1U);
    t45 = (0 + t44);
    t27 = (t28 + t45);
    t46 = 1;
    if (5U == 5U)
        goto LAB89;

LAB90:    t46 = 0;

LAB91:    if (t46 != 0)
        goto LAB86;

LAB88:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 3938);
    t6 = (t0 + 2044);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);

LAB87:    xsi_set_current_line(76, ng0);
    t1 = (t0 + 592U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 776U);
    t7 = *((char **)t6);
    t9 = (31 - 20);
    t20 = (t9 * 1U);
    t21 = (0 + t20);
    t6 = (t7 + t21);
    t8 = 1;
    if (5U == 5U)
        goto LAB98;

LAB99:    t8 = 0;

LAB100:    if (t8 != 0)
        goto LAB95;

LAB97:    xsi_set_current_line(79, ng0);
    t1 = (t0 + 3942);
    t6 = (t0 + 2080);
    t7 = (t6 + 32U);
    t10 = *((char **)t7);
    t11 = (t10 + 40U);
    t12 = *((char **)t11);
    memcpy(t12, t1, 2U);
    xsi_driver_first_trans_fast_port(t6);

LAB96:    goto LAB3;

LAB68:    t1 = (t0 + 592U);
    t6 = *((char **)t1);
    t3 = (31 - 25);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t6 + t5);
    t7 = (t0 + 776U);
    t10 = *((char **)t7);
    t9 = (31 - 20);
    t20 = (t9 * 1U);
    t21 = (0 + t20);
    t7 = (t10 + t21);
    t32 = 1;
    if (5U == 5U)
        goto LAB74;

LAB75:    t32 = 0;

LAB76:    if (t32 == 1)
        goto LAB71;

LAB72:    t13 = (t0 + 592U);
    t14 = *((char **)t13);
    t24 = (31 - 15);
    t33 = (t24 * 1U);
    t34 = (0 + t33);
    t13 = (t14 + t34);
    t15 = (t0 + 776U);
    t16 = *((char **)t15);
    t35 = (31 - 20);
    t36 = (t35 * 1U);
    t37 = (0 + t36);
    t15 = (t16 + t37);
    t38 = 1;
    if (5U == 5U)
        goto LAB80;

LAB81:    t38 = 0;

LAB82:    t31 = t38;

LAB73:    t8 = t31;
    goto LAB70;

LAB71:    t31 = (unsigned char)1;
    goto LAB73;

LAB74:    t22 = 0;

LAB77:    if (t22 < 5U)
        goto LAB78;
    else
        goto LAB76;

LAB78:    t11 = (t1 + t22);
    t12 = (t7 + t22);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB75;

LAB79:    t22 = (t22 + 1);
    goto LAB77;

LAB80:    t39 = 0;

LAB83:    if (t39 < 5U)
        goto LAB84;
    else
        goto LAB82;

LAB84:    t17 = (t13 + t39);
    t18 = (t15 + t39);
    if (*((unsigned char *)t17) != *((unsigned char *)t18))
        goto LAB81;

LAB85:    t39 = (t39 + 1);
    goto LAB83;

LAB86:    xsi_set_current_line(71, ng0);
    t48 = (t0 + 3936);
    t50 = (t0 + 2044);
    t51 = (t50 + 32U);
    t52 = *((char **)t51);
    t53 = (t52 + 40U);
    t54 = *((char **)t53);
    memcpy(t54, t48, 2U);
    xsi_driver_first_trans_fast_port(t50);
    goto LAB87;

LAB89:    t47 = 0;

LAB92:    if (t47 < 5U)
        goto LAB93;
    else
        goto LAB91;

LAB93:    t29 = (t25 + t47);
    t30 = (t27 + t47);
    if (*((unsigned char *)t29) != *((unsigned char *)t30))
        goto LAB90;

LAB94:    t47 = (t47 + 1);
    goto LAB92;

LAB95:    xsi_set_current_line(77, ng0);
    t12 = (t0 + 3940);
    t14 = (t0 + 2080);
    t15 = (t14 + 32U);
    t16 = *((char **)t15);
    t17 = (t16 + 40U);
    t18 = *((char **)t17);
    memcpy(t18, t12, 2U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB96;

LAB98:    t22 = 0;

LAB101:    if (t22 < 5U)
        goto LAB102;
    else
        goto LAB100;

LAB102:    t10 = (t1 + t22);
    t11 = (t6 + t22);
    if (*((unsigned char *)t10) != *((unsigned char *)t11))
        goto LAB99;

LAB103:    t22 = (t22 + 1);
    goto LAB101;

}


extern void work_a_0934003765_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0934003765_3212880686_p_0};
	xsi_register_didat("work_a_0934003765_3212880686", "isim/Processor_Test_isim_beh.exe.sim/work/a_0934003765_3212880686.didat");
	xsi_register_executes(pe);
}
