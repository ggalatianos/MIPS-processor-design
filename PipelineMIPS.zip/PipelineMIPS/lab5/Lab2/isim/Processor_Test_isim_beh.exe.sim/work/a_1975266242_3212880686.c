/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x2f00eba5 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/Galatis/Documents/Organwsi/1-2-3/lab5/Lab2/Stall.vhd";



static void work_a_1975266242_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned char t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    unsigned char t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned char t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned char t39;
    unsigned int t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned char t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;

LAB0:    xsi_set_current_line(50, ng0);
    t1 = (t0 + 776U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)2);
    if (t4 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 2384);
    t2 = (t1 + 32U);
    t7 = *((char **)t2);
    t11 = (t7 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB3:    t1 = (t0 + 2288);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 684U);
    t7 = *((char **)t1);
    t8 = (31 - 31);
    t9 = (t8 * 1U);
    t10 = (0 + t9);
    t1 = (t7 + t10);
    t11 = (t0 + 4211);
    t13 = 1;
    if (6U == 6U)
        goto LAB14;

LAB15:    t13 = 0;

LAB16:    if (t13 == 1)
        goto LAB11;

LAB12:    t6 = (unsigned char)0;

LAB13:    if (t6 == 1)
        goto LAB8;

LAB9:    t5 = (unsigned char)0;

LAB10:    if (t5 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 2384);
    t2 = (t1 + 32U);
    t7 = *((char **)t2);
    t11 = (t7 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(56, ng0);
    t1 = (t0 + 2348);
    t2 = (t1 + 32U);
    t7 = *((char **)t2);
    t11 = (t7 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(52, ng0);
    t57 = (t0 + 2348);
    t58 = (t57 + 32U);
    t59 = *((char **)t58);
    t60 = (t59 + 40U);
    t61 = *((char **)t60);
    *((unsigned char *)t61) = (unsigned char)3;
    xsi_driver_first_trans_fast(t57);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 2384);
    t2 = (t1 + 32U);
    t7 = *((char **)t2);
    t11 = (t7 + 40U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB8:    t29 = (t0 + 684U);
    t30 = *((char **)t29);
    t31 = (31 - 20);
    t32 = (t31 * 1U);
    t33 = (0 + t32);
    t29 = (t30 + t33);
    t34 = (t0 + 592U);
    t35 = *((char **)t34);
    t36 = (31 - 25);
    t37 = (t36 * 1U);
    t38 = (0 + t37);
    t34 = (t35 + t38);
    t39 = 1;
    if (5U == 5U)
        goto LAB29;

LAB30:    t39 = 0;

LAB31:    if (t39 == 1)
        goto LAB26;

LAB27:    t43 = (t0 + 684U);
    t44 = *((char **)t43);
    t45 = (31 - 20);
    t46 = (t45 * 1U);
    t47 = (0 + t46);
    t43 = (t44 + t47);
    t48 = (t0 + 592U);
    t49 = *((char **)t48);
    t50 = (31 - 15);
    t51 = (t50 * 1U);
    t52 = (0 + t51);
    t48 = (t49 + t52);
    t53 = 1;
    if (5U == 5U)
        goto LAB35;

LAB36:    t53 = 0;

LAB37:    t28 = t53;

LAB28:    t5 = t28;
    goto LAB10;

LAB11:    t17 = (t0 + 592U);
    t18 = *((char **)t17);
    t19 = (31 - 31);
    t20 = (t19 * 1U);
    t21 = (0 + t20);
    t17 = (t18 + t21);
    t22 = (t0 + 4217);
    t24 = 1;
    if (6U == 6U)
        goto LAB20;

LAB21:    t24 = 0;

LAB22:    t6 = t24;
    goto LAB13;

LAB14:    t14 = 0;

LAB17:    if (t14 < 6U)
        goto LAB18;
    else
        goto LAB16;

LAB18:    t15 = (t1 + t14);
    t16 = (t11 + t14);
    if (*((unsigned char *)t15) != *((unsigned char *)t16))
        goto LAB15;

LAB19:    t14 = (t14 + 1);
    goto LAB17;

LAB20:    t25 = 0;

LAB23:    if (t25 < 6U)
        goto LAB24;
    else
        goto LAB22;

LAB24:    t26 = (t17 + t25);
    t27 = (t22 + t25);
    if (*((unsigned char *)t26) != *((unsigned char *)t27))
        goto LAB21;

LAB25:    t25 = (t25 + 1);
    goto LAB23;

LAB26:    t28 = (unsigned char)1;
    goto LAB28;

LAB29:    t40 = 0;

LAB32:    if (t40 < 5U)
        goto LAB33;
    else
        goto LAB31;

LAB33:    t41 = (t29 + t40);
    t42 = (t34 + t40);
    if (*((unsigned char *)t41) != *((unsigned char *)t42))
        goto LAB30;

LAB34:    t40 = (t40 + 1);
    goto LAB32;

LAB35:    t54 = 0;

LAB38:    if (t54 < 5U)
        goto LAB39;
    else
        goto LAB37;

LAB39:    t55 = (t43 + t54);
    t56 = (t48 + t54);
    if (*((unsigned char *)t55) != *((unsigned char *)t56))
        goto LAB36;

LAB40:    t54 = (t54 + 1);
    goto LAB38;

}

static void work_a_1975266242_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(63, ng0);

LAB3:    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2420);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 2296);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_1975266242_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(64, ng0);

LAB3:    t1 = (t0 + 1144U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 2456);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 40U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 2304);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1975266242_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1975266242_3212880686_p_0,(void *)work_a_1975266242_3212880686_p_1,(void *)work_a_1975266242_3212880686_p_2};
	xsi_register_didat("work_a_1975266242_3212880686", "isim/Processor_Test_isim_beh.exe.sim/work/a_1975266242_3212880686.didat");
	xsi_register_executes(pe);
}
