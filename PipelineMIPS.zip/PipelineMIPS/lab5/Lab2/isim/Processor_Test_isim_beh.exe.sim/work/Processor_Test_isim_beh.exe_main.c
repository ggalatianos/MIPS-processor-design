/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;
char *IEEE_P_1242562249;
char *IEEE_P_0774719531;
char *IEEE_P_3499444699;
char *IEEE_P_3620187407;
char *STD_TEXTIO;
char *IEEE_P_3564397177;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    ieee_p_1242562249_init();
    ieee_p_3499444699_init();
    ieee_p_0774719531_init();
    ieee_p_3620187407_init();
    std_textio_init();
    ieee_p_3564397177_init();
    work_a_1707285540_0000452272_init();
    work_a_3279062471_3212880686_init();
    work_a_0079817525_3212880686_init();
    work_a_1991350011_3212880686_init();
    work_a_1153420228_3212880686_init();
    work_a_0586436059_3212880686_init();
    work_a_1913148318_1181938964_init();
    work_a_0279731846_3212880686_init();
    work_a_2874911341_3212880686_init();
    work_a_1427140701_3212880686_init();
    work_a_2172777829_3212880686_init();
    work_a_3222946569_3212880686_init();
    work_a_2767953198_3212880686_init();
    work_a_2263464102_3212880686_init();
    work_a_3711401645_3212880686_init();
    work_a_0290344353_3212880686_init();
    work_a_0925960817_3212880686_init();
    work_a_0734482308_3212880686_init();
    work_a_1583994426_1181938964_init();
    work_a_4122381622_3212880686_init();
    work_a_3977952979_1181938964_init();
    work_a_4169249213_3212880686_init();
    work_a_2987848946_3212880686_init();
    work_a_2000501719_3212880686_init();
    work_a_0832606739_3212880686_init();
    work_a_2128221623_1181938964_init();
    work_a_2657849955_3212880686_init();
    work_a_4200723274_3212880686_init();
    work_a_0720342707_3212880686_init();
    work_a_0934003765_3212880686_init();
    work_a_1975266242_3212880686_init();
    work_a_1640669797_3212880686_init();
    work_a_3439322065_2372691052_init();


    xsi_register_tops("work_a_3439322065_2372691052");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    IEEE_P_3564397177 = xsi_get_engine_memory("ieee_p_3564397177");

    return xsi_run_simulation(argc, argv);

}
