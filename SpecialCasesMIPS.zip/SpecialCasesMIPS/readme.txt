Sta arxeia poy 8a ziti8oun ws components 
8a ta parete apo ton fakelo lab1(ton opoio
exoume simperilavei) mesa sto zip arxeio.
Euxaristoume poli!!!